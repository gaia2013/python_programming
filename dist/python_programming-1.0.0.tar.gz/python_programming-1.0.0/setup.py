from setuptools import setup

setup(
    name='python_programming',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='****.com',
    license='free',
    author='hitoshi',
    author_email='python_programming',
    description=''
)
