from lesson_package.tools import utils

def sing():
    return '#####Rfafd'

def cry():
    return utils.say_twice('FEAFDA$#$R')